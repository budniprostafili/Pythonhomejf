import sqlite3
from contextlib import contextmanager

class Database:
    def __init__(self, db_name="smart_home.db"):
        self.db_name = db_name
        self.create_tables()

    @contextmanager
    def connect(self):
        connection = sqlite3.connect(self.db_name)
        cursor = connection.cursor()
        try:
            yield cursor
        finally:
            connection.commit()
            connection.close()

    def create_tables(self):
        with self.connect() as cursor:
            cursor.execute('''CREATE TABLE IF NOT EXISTS devices (
                                id INTEGER PRIMARY KEY,
                                name TEXT NOT NULL,
                                state TEXT NOT NULL)''')

    def add_device(self, name, state):
        with self.connect() as cursor:
            cursor.execute("INSERT INTO devices (name, state) VALUES (?, ?)", (name, state))

    def update_device_state(self, device_id, state):
        with self.connect() as cursor:
            cursor.execute("UPDATE devices SET state = ? WHERE id = ?", (state, device_id))

    def get_device_state(self, device_id):
        with self.connect() as cursor:
            cursor.execute("SELECT state FROM devices WHERE id = ?", (device_id,))
            return cursor.fetchone()

    def get_all_devices(self):
        with self.connect() as cursor:
            cursor.execute("SELECT * FROM devices")
            return cursor.fetchall()
