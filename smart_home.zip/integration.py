import requests

class WeatherIntegration:
    def __init__(self, api_key):
        self.api_key = api_key

    def get_weather(self, location):
        url = f"http://api.weatherapi.com/v1/current.json?key={self.api_key}&q={location}"
        response = requests.get(url)
        response.raise_for_status()
        return response.json()
