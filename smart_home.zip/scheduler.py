from apscheduler.schedulers.background import BackgroundScheduler
from devices import DeviceController
from datetime import datetime

class Scheduler:
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.device_controller = DeviceController()
        self.scheduler.start()

    def schedule_device(self, device_id, action, trigger_time):
        self.scheduler.add_job(lambda: self.device_controller.toggle_device(device_id),
                               'date', run_date=trigger_time)

    def add_recurring_task(self, device_id, action, trigger_time):
        self.scheduler.add_job(lambda: self.device_controller.toggle_device(device_id),
                               'interval', seconds=trigger_time)
