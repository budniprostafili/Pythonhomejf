from devices import DeviceController

class StateMonitor:
    def __init__(self):
        self.device_controller = DeviceController()

    def display_device_states(self):
        devices = self.device_controller.get_all_devices()
        for device in devices:
            print(f"Device {device[1]} is {device[2]}")
