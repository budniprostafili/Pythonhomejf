from database import Database

class DeviceController:
    def __init__(self):
        self.db = Database()

    def add_device(self, name):
        self.db.add_device(name, "off")

    def toggle_device(self, device_id):
        current_state = self.db.get_device_state(device_id)[0]
        new_state = "on" if current_state == "off" else "off"
        self.db.update_device_state(device_id, new_state)
        return new_state

    def get_device_state(self, device_id):
        return self.db.get_device_state(device_id)

    def get_all_devices(self):
        return self.db.get_all_devices()
