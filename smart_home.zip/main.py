from devices import DeviceController
from monitoring import StateMonitor
from scheduler import Scheduler
from integration import WeatherIntegration
from utils import setup_logging

def main():
    logger = setup_logging()

    device_controller = DeviceController()
    state_monitor = StateMonitor()
    scheduler = Scheduler()
    weather_integration = WeatherIntegration(api_key="your_api_key_here")

    # Example usage
    device_controller.add_device("Living Room Light")
    device_controller.toggle_device(1)
    state_monitor.display_device_states()

    # Schedule a device to toggle at a specific time
    from datetime import datetime
    scheduler.schedule_device(1, "toggle", datetime(2024, 7, 10, 12, 0))

    # Get current weather
    try:
        weather = weather_integration.get_weather("New York")
        logger.info(f"Weather in New York: {weather}")
    except requests.RequestException as e:
        logger.error(f"Error fetching weather data: {e}")

if __name__ == "__main__":
    main()
