# Smart Home System

## Description
This project is a smart home management system written in Python. It allows you to manage devices, monitor their status, and schedule tasks.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py
```

## Documentation
Documentation can be found in the `docs/` directory.