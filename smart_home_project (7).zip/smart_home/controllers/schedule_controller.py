# Placeholder for schedule controller
class ScheduleController:
    pass