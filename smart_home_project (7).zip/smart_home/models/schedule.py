# Placeholder for schedule model
class Schedule:
    pass