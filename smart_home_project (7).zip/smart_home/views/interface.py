# Placeholder for user interface
class Interface:
    pass